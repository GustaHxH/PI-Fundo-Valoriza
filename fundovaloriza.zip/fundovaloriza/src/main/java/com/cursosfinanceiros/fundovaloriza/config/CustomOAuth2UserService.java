package com.cursosfinanceiros.fundovaloriza.config;

import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

@Service
public class CustomOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {

    private final UsuarioService usuarioService;

    public CustomOAuth2UserService(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) {
        // Usamos o DefaultOAuth2UserService para carregar o usuário autenticado via Google
        OAuth2User oAuth2User = new DefaultOAuth2UserService().loadUser(userRequest);

        // Processa e salva no banco de dados, ou atualiza caso necessário
        return usuarioService.processarOAuth2User(oAuth2User);
    }
}
