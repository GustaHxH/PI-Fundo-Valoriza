package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Método para cadastrar o usuário
    public Usuario cadastrarUsuario(Usuario usuario) {
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent()) {
            throw new EmailAlreadyExistsException("E-mail já cadastrado.");
        }

        if (usuario.isAutenticadoComGoogle() && usuario.getSenha() == null) {
            usuario.setSenha(""); // Para o cadastro via Google, deixamos a senha como vazia
        } else {
            usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        }

        // Salva o usuário no banco
        return usuarioRepository.save(usuario);
    }

    // Método para buscar usuário por e-mail
    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public boolean validarSenha(String senhaOriginal, String senhaCriptografada) {
        return passwordEncoder.matches(senhaOriginal, senhaCriptografada);
    }

    // Método para verificar se o e-mail já existe
    public boolean verificarEmailExistente(String email) {
        return usuarioRepository.findByEmail(email).isPresent();
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Busca o usuário pelo e-mail (username)
        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));

        // Criação do UserDetails com o nome real e o e-mail
        return buildUser(usuario);
    }

    // Método para carregar um usuário OAuth2 (Google)
    public OAuth2User loadOAuth2UserByUsername(OAuth2UserRequest userRequest) {
        OAuth2User oAuth2User = new DefaultOAuth2UserService().loadUser(userRequest);

        String email = oAuth2User.getAttribute("email");

        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);

        Usuario usuario;
        if (usuarioExistente.isPresent()) {
            usuario = usuarioExistente.get();
        } else {
            usuario = new Usuario();
            usuario.setNome(oAuth2User.getAttribute("name"));
            usuario.setEmail(email);
            usuario.setAutenticadoComGoogle(true);
            usuario.setSenha("");  // Senha vazia para usuários Google

            usuario = usuarioRepository.save(usuario);  // Certifique-se de que isso está sendo chamado corretamente
        }

        return oAuth2User;
    }

    public Usuario atualizarPerfil(String username, String name, String email) {
        // O username no caso de OAuth2 é o 'sub' (ID do usuário), mas queremos usar o e-mail
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);

        if (usuarioExistente.isPresent()) {
            Usuario usuario = usuarioExistente.get();
            usuario.setNome(name);  // Atualiza o nome
            usuario.setEmail(email);  // Atualiza o e-mail

            // Salva o usuário atualizado no banco de dados
            return usuarioRepository.save(usuario);
        }

        return null; // Se o usuário não for encontrado
    }

    // Método para processar usuário OAuth2
    public OAuth2User processarOAuth2User(OAuth2User oAuth2User) {
        String email = oAuth2User.getAttribute("email");

        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);

        Usuario usuario;
        if (usuarioExistente.isPresent()) {
            usuario = usuarioExistente.get();
        } else {
            usuario = new Usuario();
            usuario.setNome(oAuth2User.getAttribute("name"));
            usuario.setEmail(email);
            usuario.setAutenticadoComGoogle(true);
            usuario.setSenha("");  // Senha vazia para login via Google

            usuario = usuarioRepository.save(usuario);
        }

        return oAuth2User;  // Retorna o OAuth2User para o Spring Security
    }

    public Usuario getUsuarioLogado() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof OAuth2User) {
            OAuth2User oAuth2User = (OAuth2User) principal;
            String email = oAuth2User.getAttribute("email");

            return usuarioRepository.findByEmail(email)
                    .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
        } else if (principal instanceof User) {
            User user = (User) principal;
            return usuarioRepository.findByEmail(user.getUsername())
                    .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
        } else {
            throw new IllegalStateException("Usuário não autenticado");
        }
    }




    private UserDetails buildUser(Usuario usuario) {
        return User.withUsername(usuario.getNome())
                .password(usuario.getSenha())
                .authorities("ROLE_USER")
                .build();
    }
}

// Exceção personalizada para e-mail já existente
class EmailAlreadyExistsException extends RuntimeException {
    public EmailAlreadyExistsException(String message) {
        super(message);
    }
}
