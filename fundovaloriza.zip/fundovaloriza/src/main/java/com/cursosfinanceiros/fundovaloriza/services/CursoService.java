package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Curso;
import com.cursosfinanceiros.fundovaloriza.repositories.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    // Listar todos os cursos
    public List<Curso> listarTodosCursos() {
        return cursoRepository.findAll();
    }

    // Salvar um novo curso ou atualizar um curso existente
    public Curso salvarCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    // Buscar curso por id
    public Curso buscarCursoPorId(String id) {
        Optional<Curso> curso = cursoRepository.findById(id);
        return curso.orElse(null); // Retorna null se não encontrar o curso
    }

    // Excluir curso
    public void deletarCurso(String id) {
        cursoRepository.deleteById(id);
    }
}
