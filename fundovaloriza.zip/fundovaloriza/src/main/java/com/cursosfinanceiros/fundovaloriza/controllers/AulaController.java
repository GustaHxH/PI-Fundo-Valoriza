package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Aula;
import com.cursosfinanceiros.fundovaloriza.models.Curso;
import com.cursosfinanceiros.fundovaloriza.services.AulaService;
import com.cursosfinanceiros.fundovaloriza.services.CursoService;
import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.Image;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.io.FileInputStream;

@Controller
public class AulaController {

    @Autowired
    private CursoService cursoService;  // Serviço para buscar o curso

    @Autowired
    private AulaService aulaService;

    @Autowired
    private UsuarioService usuarioService; // Injeção do UsuarioService

    @GetMapping("/aulas")
    public String listarAulas(@RequestParam("id") String cursoId, Model model) {
        model.addAttribute("aulas", aulaService.listarAulasPorCurso(cursoId));
        model.addAttribute("cursoId", cursoId);

        // Verifica se todas as aulas foram concluídas
        boolean todasAulasConcluidas = aulaService.todasAulasConcluidas(cursoId);
        model.addAttribute("todasAulasConcluidas", todasAulasConcluidas);

        return "aulas";  // Redireciona para o template aulas.html
    }

    @GetMapping("/aulas/gerarCertificado")
    public void gerarCertificado(@RequestParam("cursoId") String cursoId, HttpServletResponse response) throws DocumentException, IOException {
        // Verifica se o cursoId é válido
        if (cursoId == null || cursoId.trim().isEmpty()) {
            throw new IllegalArgumentException("Curso ID inválido.");
        }

        // Buscar o curso usando o cursoService
        Curso curso = cursoService.buscarCursoPorId(cursoId);
        if (curso == null) {
            System.out.println("Curso não encontrado para o ID: " + cursoId); // Log para ajudar na depuração
            throw new IllegalArgumentException("Curso não encontrado. Verifique se o curso está cadastrado.");
        }

        // Recupera o nome do curso e o usuário
        String nomeCurso = curso.getNome();
        String horas = "Horas: " + curso.getDuracao() + " horas"; // A duração do curso
        String nomeUsuario = usuarioService.getUsuarioLogado().getNome();  // Obtém o nome do usuário logado

        // Configura o cabeçalho para o tipo de conteúdo PDF
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=\"certificado_" + nomeCurso + ".pdf\"");

        // Gerar o certificado em PDF com A5 horizontal
        Document document = new Document(new com.itextpdf.text.Rectangle(595, 420));  // Tamanho A5 horizontal em pontos
        PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        // Caminho para a imagem
        String caminhoImagem = "src/main/resources/static/imagens/certificado-de-conclusao-simples-azul.png";  // Caminho para a imagem
        Image background = Image.getInstance(caminhoImagem); // Usando o método correto para carregar a imagem
        background.scaleToFit(595, 420); // Ajusta a imagem para o tamanho A5 horizontal
        background.setAbsolutePosition(0, 0); // Coloca a imagem no fundo
        document.add(background);

        // Carregar fontes personalizadas
        Font fontTitulo = FontFactory.getFont("src/main/resources/fonts/29LTZaridSerif.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 30, Font.BOLD, BaseColor.BLUE);
        Font fontNome = FontFactory.getFont("src/main/resources/fonts/AlexBrush-Regular.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 36, Font.BOLD, BaseColor.BLUE);
        Font fontTexto = FontFactory.getFont("src/main/resources/fonts/29LTZaridSerif.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 18, Font.NORMAL, BaseColor.BLACK);

        // Adicionar título centralizado
        com.itextpdf.text.Paragraph pTitulo = new com.itextpdf.text.Paragraph("CERTIFICADO", fontTitulo);
        pTitulo.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
        pTitulo.setSpacingBefore(20);  // Ajuste o espaçamento para posicionar o título mais para cima
        document.add(pTitulo);

        // Adicionar texto centralizado
        com.itextpdf.text.Paragraph pTexto = new com.itextpdf.text.Paragraph("ESTE CERTIFICADO COMPROVA QUE", fontTexto);
        pTexto.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
        pTexto.setSpacingBefore(10);  // Ajuste o espaçamento para posicionar o texto mais para cima
        document.add(pTexto);

        // Nome do aluno centralizado
        com.itextpdf.text.Paragraph pNome = new com.itextpdf.text.Paragraph(nomeUsuario, fontNome);
        pNome.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
        pNome.setSpacingBefore(0);  // Ajuste o espaçamento para posicionar o nome mais para cima
        document.add(pNome);

        // Texto adicional sobre o curso
        com.itextpdf.text.Paragraph pCurso = new com.itextpdf.text.Paragraph("CONCLUIU COM ÊXITO O CURSO " + nomeCurso + " E DEMONSTROU DEDICAÇÃO E EMPENHO EXEMPLORES.", fontTexto);
        pCurso.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
        pCurso.setSpacingBefore(20);  // Ajuste o espaçamento para posicionar o texto mais para cima
        document.add(pCurso);

        // Formatar a data para o formato brasileiro (dd/MM/yyyy)
        String dataFormatada = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));

// Texto para data
        com.itextpdf.text.Paragraph pData = new com.itextpdf.text.Paragraph("PARABÉNS E BOA SORTE NO FUTURO. EMITIDO EM " + dataFormatada, fontTexto);
        pData.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
        pData.setSpacingBefore(10);  // Ajuste o espaçamento para a data
        document.add(pData);





        // Fechar o documento
        document.close();
    }





    @PostMapping("/aulas")
    public String adicionarAula(@ModelAttribute Aula aula, @RequestParam("cursoId") String cursoId) {
        aula.setCursoId(cursoId);

        // Conversão automática de YouTube watch para embed
        if (aula.getUrlVideo() != null && aula.getUrlVideo().contains("watch?v=")) {
            String embedUrl = aula.getUrlVideo().replace("watch?v=", "embed/");
            aula.setUrlVideo(embedUrl);
        }

        aulaService.salvarAula(aula);
        return "redirect:/aulas?id=" + cursoId;
    }

    @GetMapping("/aulas/editar/{id}")
    public String exibirFormularioEdicao(@PathVariable("id") String id, Model model) {
        Aula aula = aulaService.buscarPorId(id);
        model.addAttribute("aula", aula);
        model.addAttribute("cursoId", aula.getCursoId());
        model.addAttribute("aulas", aulaService.listarAulasPorCurso(aula.getCursoId()));
        return "formularioAulas"; // reutilizando o mesmo template
    }

    @PostMapping("/aulas/editar/{id}")
    public String editarAula(@PathVariable("id") String id, @ModelAttribute Aula aula, @RequestParam("cursoId") String cursoId) {
        aula.setId(id);
        aula.setCursoId(cursoId);

        // Conversão automática de YouTube watch para embed
        if (aula.getUrlVideo() != null && aula.getUrlVideo().contains("watch?v=")) {
            aula.setUrlVideo(aula.getUrlVideo().replace("watch?v=", "embed/"));
        }

        aulaService.salvarAula(aula);
        return "redirect:/aulas?id=" + cursoId;
    }

    @GetMapping("/aulas/excluir/{id}")
    public String excluirAula(@PathVariable("id") String id, @RequestParam("cursoId") String cursoId) {
        aulaService.deletarAula(id);
        return "redirect:/aulas?id=" + cursoId;
    }

    @GetMapping("/aulas/formulario")
    public String formularioAula(@RequestParam(value = "id", required = false) String id, @RequestParam("cursoId") String cursoId, Model model) {
        Aula aula = (id != null) ? aulaService.buscarPorId(id) : new Aula();
        model.addAttribute("aula", aula);
        model.addAttribute("cursoId", cursoId);
        return "formularioAulas"; // Renderiza formularioAulas.html
    }

    @GetMapping("/aulas/assistir/{id}")
    public String assistirAula(@PathVariable("id") String id, Model model) {
        // Recupera a aula pelo id
        Aula aula = aulaService.buscarPorId(id);
        if (aula != null) {
            // Adiciona os dados da aula ao modelo para exibição
            model.addAttribute("aula", aula);

            // Adiciona o usuário logado ao modelo
            model.addAttribute("usuario", usuarioService.getUsuarioLogado());

            return "assistirAula";  // Nome da página que exibirá o vídeo
        }
        return "redirect:/aulas";  // Redireciona caso não encontre a aula
    }

    @PostMapping("/aulas/concluir/{id}")
    public String concluirAula(@PathVariable("id") String id) {
        aulaService.atualizarStatusAula(id, true);  // Atualiza o status da aula para 'concluída' para o usuário logado
        return "redirect:/aulas/assistir/" + id;  // Redireciona de volta para a página de visualização da aula
    }

}
