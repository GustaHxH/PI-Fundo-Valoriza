package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Inscricao;
import com.cursosfinanceiros.fundovaloriza.models.Curso;
import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.repositories.InscricaoRepository;
import com.cursosfinanceiros.fundovaloriza.repositories.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InscricaoService {

    @Autowired
    private InscricaoRepository inscricaoRepository;

    @Autowired
    private CursoRepository cursoRepository;

    // Verifica se o usuário está inscrito no curso
    public boolean isInscrito(String usuarioId, String cursoId) {
        return inscricaoRepository.existsByUsuarioIdAndCursoId(usuarioId, cursoId);
    }

    // Inscreve o usuário no curso
    public void inscrever(String usuarioId, String cursoId) {
        Curso curso = cursoRepository.findById(cursoId).orElse(null);
        if (curso != null) {
            Inscricao inscricao = new Inscricao(usuarioId, cursoId, true);
            inscricaoRepository.save(inscricao);
        }
    }
}
