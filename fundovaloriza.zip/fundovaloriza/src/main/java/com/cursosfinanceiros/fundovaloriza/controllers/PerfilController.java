package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.services.UsuarioService; // Injeta o serviço de usuário
import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PerfilController {

    @Autowired
    private UsuarioService usuarioService; // Injeta o serviço de usuário

    // Exibe o perfil do usuário
    @GetMapping("/perfil/{username}")
    public String exibirPerfil(@PathVariable String username, Model model) {
        Usuario usuario = usuarioService.buscarPorEmail(username).orElse(null); // Buscando o usuário pelo email (username)
        model.addAttribute("usuario", usuario); // Passa o usuário atualizado para o modelo
        return "perfil"; // Retorna o template perfil.html
    }

    // Método para atualizar as informações do usuário
    @PostMapping("/perfil/atualizar")
    public String atualizarPerfil(@RequestParam String name, @RequestParam String email, Authentication authentication) {
        String username = authentication.getName(); // Obtém o nome de usuário (que é o email)

        // Atualiza o perfil do usuário no banco de dados utilizando o serviço
        usuarioService.atualizarPerfil(username, name, email);

        // Após a atualização, redireciona para o perfil atualizado
        return "redirect:/perfil/" + username;
    }
}
