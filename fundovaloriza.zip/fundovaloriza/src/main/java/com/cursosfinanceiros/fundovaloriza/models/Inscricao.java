package com.cursosfinanceiros.fundovaloriza.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "inscricoes")
public class Inscricao {

    @Id
    private String id;

    private String usuarioId;  // Relacionamento com o usuário
    private String cursoId;    // Relacionamento com o curso
    private boolean inscrito;  // Status de inscrição

    // Construtores, getters e setters
    public Inscricao(String usuarioId, String cursoId, boolean inscrito) {
        this.usuarioId = usuarioId;
        this.cursoId = cursoId;
        this.inscrito = inscrito;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getCursoId() {
        return cursoId;
    }

    public void setCursoId(String cursoId) {
        this.cursoId = cursoId;
    }

    public boolean isInscrito() {
        return inscrito;
    }

    public void setInscrito(boolean inscrito) {
        this.inscrito = inscrito;
    }
}
