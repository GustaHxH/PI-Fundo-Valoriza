package com.cursosfinanceiros.fundovaloriza.repositories;

import com.cursosfinanceiros.fundovaloriza.models.Inscricao;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InscricaoRepository extends MongoRepository<Inscricao, String> {
    boolean existsByUsuarioIdAndCursoId(String usuarioId, String cursoId);
}
