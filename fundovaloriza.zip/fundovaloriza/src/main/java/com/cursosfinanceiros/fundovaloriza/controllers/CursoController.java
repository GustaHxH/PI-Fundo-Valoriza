package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Curso;
import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.services.CursoService;
import com.cursosfinanceiros.fundovaloriza.services.InscricaoService;
import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Collectors;

@Controller
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @Autowired
    private InscricaoService inscricaoService;

    @Autowired
    private UsuarioService usuarioService;  // Para pegar o usuário logado

    // Exibir a lista de cursos
    @GetMapping("/cursos")
    public String listarCursos(Model model) {
        // Pega o usuário logado
        Usuario usuario = usuarioService.getUsuarioLogado();

        // Lista todos os cursos
        model.addAttribute("cursos", cursoService.listarTodosCursos().stream().map(curso -> {
            // Verifica se o usuário está inscrito em cada curso
            boolean inscrito = inscricaoService.isInscrito(usuario.getId(), curso.getId());
            curso.setInscrito(inscrito);  // Atualiza o campo inscrito do curso
            return curso;
        }).collect(Collectors.toList()));

        return "cursos";  // Template cursos.html
    }

    // Exibir o formulário para criar um novo curso
    @GetMapping("/cursos/novo")
    public String exibirFormularioCriacao(Model model) {
        model.addAttribute("curso", new Curso());
        return "formularioCurso";  // Template para criação de curso
    }

    // Processar o formulário de criação de curso
    @PostMapping("/cursos")
    public String criarCurso(@ModelAttribute Curso curso) {
        cursoService.salvarCurso(curso);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    // Exibir o formulário para editar um curso existente
    @GetMapping("/cursos/editar/{id}")
    public String exibirFormularioEdicao(@PathVariable("id") String id, Model model) {
        Curso curso = cursoService.buscarCursoPorId(id);
        model.addAttribute("curso", curso);
        return "formularioCurso";  // Template formularioCurso.html
    }

    // Processar o formulário de edição de curso
    @PostMapping("/cursos/editar/{id}")
    public String editarCurso(@PathVariable("id") String id, @ModelAttribute Curso curso) {
        curso.setId(id);  // Garantir que o ID seja mantido
        cursoService.salvarCurso(curso);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    // Excluir um curso
    @GetMapping("/cursos/excluir/{id}")
    public String excluirCurso(@PathVariable("id") String id) {
        cursoService.deletarCurso(id);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    // Método para inscrever no curso
    @PostMapping("/inscrever/{id}")
    public String inscreverNoCurso(@PathVariable("id") String cursoId) {
        // Pega o usuário logado
        Usuario usuario = usuarioService.getUsuarioLogado();

        // Verifica se o usuário já está inscrito no curso
        if (!inscricaoService.isInscrito(usuario.getId(), cursoId)) {
            // Inscreve o usuário no curso
            inscricaoService.inscrever(usuario.getId(), cursoId);
        }

        return "redirect:/aulas?id=" + cursoId;  // Redireciona para as aulas do curso
    }
}
