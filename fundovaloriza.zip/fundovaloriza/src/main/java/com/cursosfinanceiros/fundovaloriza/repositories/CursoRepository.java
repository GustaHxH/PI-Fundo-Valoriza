package com.cursosfinanceiros.fundovaloriza.repositories;

import com.cursosfinanceiros.fundovaloriza.models.Curso;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface CursoRepository extends MongoRepository<Curso, String> {
    List<Curso> findByNomeContainingIgnoreCase(String nome);
}
