package com.cursosfinanceiros.fundovaloriza.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CertificadoController {

    @GetMapping("/certificado")
    public String exibirCertificado(Model model) {
        // Lógica para buscar e exibir o certificado do usuário
        return "certificado"; // Template certificado.html
    }
}
