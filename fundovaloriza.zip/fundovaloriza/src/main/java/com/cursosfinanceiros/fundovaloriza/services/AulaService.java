package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Aula;
import com.cursosfinanceiros.fundovaloriza.repositories.AulaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AulaService {

    @Autowired
    private AulaRepository aulaRepository;

    @Autowired
    private UsuarioService usuarioService;

    public List<Aula> listarAulasPorCurso(String cursoId) {
        return aulaRepository.findByCursoIdOrderByIdDesc(cursoId); // mais recentes primeiro
    }

    public void salvarAula(Aula aula) {
        aulaRepository.save(aula);
    }

    public void deletarAula(String id) {
        aulaRepository.deleteById(id);
    }

    public Aula buscarPorId(String id) {
        return aulaRepository.findById(id).orElse(null);
    }
    public Aula buscarAulaPorCursoId(String cursoId) {
        return aulaRepository.findByCursoId(cursoId).stream().findFirst().orElse(null);
    }




    public boolean todasAulasConcluidas(String cursoId) {
        // Busca todas as aulas do curso
        List<Aula> aulas = aulaRepository.findByCursoId(cursoId);

        // Verifica se todas as aulas foram concluídas
        for (Aula aula : aulas) {
            if (aula.getUsuariosConcluidos().isEmpty()) {
                return false; // Se uma aula não foi concluída, retorna falso
            }
        }
        return true; // Se todas as aulas foram concluídas
    }


    public void atualizarStatusAula(String id, boolean concluida) {
        Aula aula = buscarPorId(id);
        if (aula != null) {
            // Recupera o usuário logado
            String usuarioId = usuarioService.getUsuarioLogado().getId();

            if (concluida) {
                // Adiciona o usuário à lista de usuários que concluíram a aula
                if (!aula.getUsuariosConcluidos().contains(usuarioId)) {
                    aula.getUsuariosConcluidos().add(usuarioId);
                    salvarAula(aula);
                }
            } else {
                // Se o status for alterado para não concluído, remove o usuário
                aula.getUsuariosConcluidos().remove(usuarioId);
                salvarAula(aula);
            }
        }
    }

}
